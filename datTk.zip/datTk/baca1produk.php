<?php
include_once "koneks.php";

$id_produk = isset($_GET['id_produk']) ? $_GET['id_produk'] : ''; // Check if idProduk is passed

if (!empty($id_produk)) {

    // If idProduk is a valid number, we will query the database
    $query = "SELECT * FROM produk WHERE id_produk = '" . $conn->real_escape_string($id_produk) . "'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Query Error: ' . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) > 0) {
        $produk = mysqli_fetch_assoc($result);
        header('Content-Type: application/json');
        echo json_encode($produk);
    } else {
        header('HTTP/1.1 404 Not Found');
        echo json_encode(['error' => 'Produk tidak ditemukan']);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Invalid ID']);
}

mysqli_close($conn);
