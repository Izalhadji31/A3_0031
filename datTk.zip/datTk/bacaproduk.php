<?php
// Menyertakan file koneksi
include('koneks.php');

// Memeriksa metode HTTP
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $query = "SELECT * FROM produk";
    $result = mysqli_query($conn, $query);

    $produk = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $produk[] = $row;
    }

    // Menampilkan hasil dalam format JSON
    echo json_encode($produk);
} else {
    echo json_encode(array("message" => "Metode tidak didukung."));
}

mysqli_close($conn);
?>
