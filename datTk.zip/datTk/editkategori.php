<?php

// Koneksi ke database
include_once 'koneks.php';

// Set header untuk mendukung CORS dan JSON
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

// Membaca data JSON dari request
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Periksa metode HTTP
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Validasi data yang dikirim
    $id_kategori = $data['id_kategori'] ?? 0;
    $nama_kategori = $data['nama_kategori'] ?? '';
    $deskripsi_kategori = $data['deskripsi_kategori'] ?? '';

    if (empty($id_kategori) || empty($nama_kategori) || empty($deskripsi_kategori)) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid or missing data"]);
        exit;
    }

    // Query untuk memperbarui data kategori
    $query = "UPDATE kategori SET 
                nama_kategori = '$nama_kategori', 
                deskripsi_kategori = '$deskripsi_kategori' 
              WHERE id_kategori = $id_kategori";

    $result = mysqli_query($conn, $query);

    // Cek apakah pembaruan berhasil
    if ($result && mysqli_affected_rows($conn) > 0) {
        echo json_encode(["message" => "Kategori berhasil diperbarui"]);
    } elseif ($result && mysqli_affected_rows($conn) === 0) {
        http_response_code(404);
        echo json_encode(["error" => "Kategori tidak ditemukan"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Gagal memperbarui kategori"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}

mysqli_close($conn);

?>
