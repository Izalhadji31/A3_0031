<?php
// Database connection
include_once "koneks.php";

$id_merk = isset($_GET['id_merk']) ? $_GET['id_merk'] : ''; // Check if idMerk is passed

if (!empty($id_merk)) {
    // Prepare the SQL query using real_escape_string to prevent SQL injection
    $query = "SELECT * FROM merk WHERE id_merk = '" . $conn->real_escape_string($id_merk) . "'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Query Error: ' . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) > 0) {
        $merk = mysqli_fetch_assoc($result);
        header('Content-Type: application/json');
        echo json_encode($merk);
    } else {
        header('HTTP/1.1 404 Not Found');
        echo json_encode(['error' => 'Merk tidak ditemukan']);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Invalid ID']);
}

mysqli_close($conn);
?>
