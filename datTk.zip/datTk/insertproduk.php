<?php

// Database connection
include_once 'koneks.php';

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Insert Produk
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $namaProduk = $data['namaProduk'] ?? '';
    $deskripsiProduk = $data['deskripsiProduk'] ?? '';
    $harga = $data['harga'] ?? 0;
    $stok = $data['stok'] ?? 0;
    $idKategori = $data['idKategori'] ?? 0;
    $idPemasok = $data['idPemasok'] ?? 0;
    $idMerk = $data['idMerk'] ?? 0;

    if (empty($namaProduk) || $harga <= 0 || $stok <= 0 || $idKategori <= 0 || $idPemasok <= 0 || $idMerk <= 0) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid or missing data"]);
        exit;
    }

    $query = "INSERT INTO produk (nama_produk, deskripsi_produk, harga, stok, id_kategori, id_pemasok, id_merk) VALUES ('$namaProduk', '$deskripsiProduk', $harga, $stok, $idKategori, $idPemasok, $idMerk)";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo json_encode(["message" => "Produk berhasil ditambahkan"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Gagal menambahkan produk"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}

?>
