<?php
// Database connection
include_once "koneks.php";

$id_kategori = isset($_GET['id_kategori']) ? $_GET['id_kategori'] : ''; // Check if id_kategori is passed

if (!empty($id_kategori)) {
    // Prepare the SQL query using real_escape_string to prevent SQL injection
    $query = "SELECT * FROM kategori WHERE id_kategori = '" . $conn->real_escape_string($id_kategori) . "'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Query Error: ' . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) > 0) {
        $kategori = mysqli_fetch_assoc($result);
        header('Content-Type: application/json');
        echo json_encode($kategori);
    } else {
        header('HTTP/1.1 404 Not Found');
        echo json_encode(['error' => 'Kategori tidak ditemukan']);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Invalid ID']);
}

mysqli_close($conn);
?>
