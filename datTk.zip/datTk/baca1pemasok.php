<?php
// Database connection
include_once "koneks.php";

$id_pemasok = isset($_GET['id_pemasok']) ? $_GET['id_pemasok'] : ''; // Check if idPemasok is passed

if (!empty($id_pemasok)) {
    // Prepare the SQL query using real_escape_string to prevent SQL injection
    $query = "SELECT * FROM pemasok WHERE id_pemasok = '" . $conn->real_escape_string($id_pemasok) . "'";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Query Error: ' . mysqli_error($conn));
    }

    if (mysqli_num_rows($result) > 0) {
        $pemasok = mysqli_fetch_assoc($result);
        header('Content-Type: application/json');
        echo json_encode($pemasok);
    } else {
        header('HTTP/1.1 404 Not Found');
        echo json_encode(['error' => 'Pemasok tidak ditemukan']);
    }
} else {
    header('HTTP/1.1 400 Bad Request');
    echo json_encode(['error' => 'Invalid ID']);
}

mysqli_close($conn);
?>
