<?php

// Koneksi ke database
include_once 'koneks.php';

// Set header untuk mendukung CORS dan JSON
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

// Membaca data JSON dari request
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Periksa metode HTTP
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    // Validasi data yang dikirim
    $id_produk = $data['id_produk'] ?? 0;
    $nama_produk = $data['nama_produk'] ?? '';
    $deskripsi_produk = $data['deskripsi_produk'] ?? '';
    $harga = $data['harga'] ?? 0;
    $stok = $data['stok'] ?? 0;
    $id_kategori = $data['id_kategori'] ?? 0;
    $id_pemasok = $data['id_pemasok'] ?? 0;
    $id_merk = $data['id_merk'] ?? 0;

    if (empty($id_produk) || empty($nama_produk) || $harga <= 0 || $stok <= 0 || $id_kategori <= 0 || $id_pemasok <= 0 || $id_merk <= 0) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid or missing data"]);
        exit;
    }

    // Query untuk memperbarui data produk
    $query = "UPDATE produk SET 
                nama_produk = '$nama_produk', 
                deskripsi_produk = '$deskripsi_produk', 
                harga = $harga, 
                stok = $stok, 
                id_kategori = $id_kategori, 
                id_pemasok = $id_pemasok, 
                id_merk = $id_merk 
              WHERE id_produk = $id_produk";

    $result = mysqli_query($conn, $query);

    // Cek apakah pembaruan berhasil
    if ($result && mysqli_affected_rows($conn) > 0) {
        echo json_encode(["message" => "Produk berhasil diperbarui"]);
    } elseif ($result && mysqli_affected_rows($conn) === 0) {
        http_response_code(404);
        echo json_encode(["error" => "Produk tidak ditemukan"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Gagal memperbarui produk"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}

mysqli_close($conn);

?>
