<?php

// Database connection
include_once 'koneks.php';

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Delete Produk
if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $idProduk = $data['idProduk'] ?? 0; // Get the product ID

    // Check if the product ID is provided and valid
    if (empty($idProduk) || !is_numeric($idProduk)) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid or missing Product ID"]);
        exit;
    }

    // Prepare the DELETE SQL query using prepared statements to prevent SQL injection
    $query = "DELETE FROM produk WHERE id_produk = ?";
    $stmt = mysqli_prepare($conn, $query);

    if ($stmt) {
        // Bind the parameter
        mysqli_stmt_bind_param($stmt, 'i', $idProduk);

        // Execute the query
        mysqli_stmt_execute($stmt);

        // Check if any rows were affected
        if (mysqli_stmt_affected_rows($stmt) > 0) {
            echo json_encode(["message" => "Produk berhasil dihapus"]);
        } else {
            http_response_code(404);
            echo json_encode(["error" => "Produk tidak ditemukan"]);
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Gagal menyiapkan query"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}

// Close the database connection
mysqli_close($conn);

?>
