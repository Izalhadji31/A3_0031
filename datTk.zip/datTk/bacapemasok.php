<?php
// Menyertakan file koneksi
include('koneks.php');

// Memeriksa metode HTTP
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $query = "SELECT * FROM pemasok";
    $result = mysqli_query($conn, $query);

    $pemasok = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $pemasok[] = $row;
    }

    // Menampilkan hasil dalam format JSON
    echo json_encode($pemasok);
} else {
    echo json_encode(array("message" => "Metode tidak didukung."));
}

mysqli_close($conn);
?>
