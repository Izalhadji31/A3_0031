<?php
// Koneksi database
$server = "localhost";
$user = "root";
$password = "";
$database = "dataToko";

$conn = mysqli_connect($server, $user, $password, $database);
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
