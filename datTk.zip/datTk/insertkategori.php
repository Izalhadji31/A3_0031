<?php

// Database connection
include_once 'koneks.php';

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Insert Kategori
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $namaKategori = $data['namaKategori'] ?? '';
    $deskripsiKategori = $data['deskripsiKategori'] ?? '';

    if (empty($namaKategori)) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid or missing data"]);
        exit;
    }

    // Prepare the query to insert the new kategori
    $query = "INSERT INTO kategori (nama_kategori, deskripsi_kategori) VALUES ('$namaKategori', '$deskripsiKategori')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo json_encode(["message" => "Kategori berhasil ditambahkan"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Gagal menambahkan kategori"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}

?>
