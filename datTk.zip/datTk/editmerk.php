<?php

// Menyertakan file koneksi
include('koneks.php');

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Memeriksa metode HTTP
if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $idMerk = $data['idMerk'] ?? 0;
    $namaMerk = $data['namaMerk'] ?? '';
    $deskripsiMerk = $data['deskripsiMerk'] ?? '';

    // Validasi input
    if (empty($idMerk) || empty($namaMerk)) {
        http_response_code(400);
        echo json_encode(["error" => "ID Merk atau Nama Merk tidak boleh kosong"]);
        exit;
    }

    // Query untuk memperbarui data merk
    $query = "UPDATE merk SET nama_merk = '$namaMerk', deskripsi_merk = '$deskripsiMerk' WHERE id_merk = $idMerk";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_affected_rows($conn) > 0) {
        echo json_encode(["message" => "Merk berhasil diperbarui"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Gagal memperbarui merk atau data tidak ditemukan"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Metode tidak didukung"]);
}

mysqli_close($conn);

?>
