<?php
// Menyertakan file koneksi
include('koneks.php');

// Memeriksa metode HTTP
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $query = "SELECT * FROM kategori";
    $result = mysqli_query($conn, $query);

    $kategori = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $kategori[] = $row;
    }

    // Menampilkan hasil dalam format JSON
    echo json_encode($kategori);
} else {
    echo json_encode(array("message" => "Metode tidak didukung."));
}

mysqli_close($conn);
?>
