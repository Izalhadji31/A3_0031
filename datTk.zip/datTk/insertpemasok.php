<?php

// Database connection
include_once 'koneks.php';

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');

$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Insert Pemasok
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $namaPemasok = $data['namaPemasok'] ?? '';
    $alamatPemasok = $data['alamatPemasok'] ?? '';
    $teleponPemasok = $data['teleponPemasok'] ?? '';
    $emailPemasok = $data['emailPemasok'] ?? '';

    if (empty($namaPemasok)) {
        http_response_code(400);
        echo json_encode(["error" => "Invalid or missing data"]);
        exit;
    }

    // Prepare the query to insert the new pemasok (supplier)
    $query = "INSERT INTO pemasok (nama_pemasok, alamat_pemasok, telepon_pemasok, email_pemasok) VALUES ('$namaPemasok', '$alamatPemasok', '$teleponPemasok', '$emailPemasok')";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo json_encode(["message" => "Pemasok berhasil ditambahkan"]);
    } else {
        http_response_code(500);
        echo json_encode(["error" => "Gagal menambahkan pemasok"]);
    }
} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}

?>
